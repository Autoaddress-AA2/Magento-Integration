<?php
	if($_POST['submit']) {
		global $wpdb;
		$table_name= $wpdb->prefix."autoaddress";	
		$add_profile = $_POST['profile_name'];
		$lic_key = $_POST['licence_key'];
		$billing_company = $_POST['billing_company'];
		$billing_addressline1 = $_POST['billing_addressline1'];
		$billing_addressline2 = $_POST['billing_addressline2'];
		$billing_city = $_POST['billing_city'];
		$billing_county = $_POST['billing_county'];
		$billing_eircode = $_POST['billing_eircode'];
		$delivery_company = $_POST['delivery_company'];
		$delivery_addressline1 = $_POST['delivery_addressline1'];
		$delivery_addressline2 = $_POST['delivery_addressline2'];
		$delivery_city = $_POST['delivery_city'];
		$delivery_county = $_POST['delivery_county'];
		$delivery_eircode = $_POST['delivery_eircode'];

		$success = $wpdb->insert("$table_name", array(
		"add_profile" => $add_profile,
		"lic_key" => $lic_key,
		"billing_company" => $billing_company,
		"billing_addressline1" => $billing_addressline1,
		"billing_addressline2" => $billing_addressline2,
		"billing_city" => $billing_city,
		"billing_county" => $billing_county,
		"billing_eircode" =>$billing_eircode,
		"delivery_company" => $delivery_company,
		"delivery_addressline1" =>$delivery_addressline1,
		"delivery_addressline2" =>$delivery_addressline2,
		"delivery_city" =>$delivery_city,
		"delivery_county" =>$delivery_county,
		"delivery_eircode" =>$delivery_eircode,				
		"created_date"=>date('Y-m-d H:i:s'),
	));
	if($success) {
		echo '<div class="notice inline notice-success is-dismissible">
			 <p>Data Saved Successfully!!!</p>
		</div>';	
      } else { 
		echo '<div class="notice inline notice-error is-dismissible">
			 <p>Error Occured!!</p>
		</div>';
	}
	}

	global $wpdb;
	$table_name= $wpdb->prefix."autoaddress";	
	$DBP_results = $wpdb->GET_ROW("SELECT * FROM $table_name ORDER BY created_date DESC LIMIT 1");
?>
<form action ="<?php echo $_SERVER['REQUEST_URI']; ?>" method ="post">
<?php

	echo '<h2  align="center" style="margin-top:50px; padding-top:5px; padding-left:10px;"><span><i class="fa fa-cogs"></i> General Settings</span></h2>';
	echo '<table width="820px" align="center" style=" border: 1px solid black; margin-top:50px; padding-top:5px; padding-left:10px; border-collapse:separate; border-spacing:2em;">';       
	echo '<tr >';
	echo ' <td valign="top">';
	echo '  <label for="profile_name" style="padding-left:300px;"><strong>Profile Name </strong></label>';
	echo ' </td>';
	echo ' <td valign="top">';
	echo '  <textarea id="profile_name" required type="text" name="profile_name" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; "/>'. $DBP_results->add_profile .'</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="licence_key" style="padding-left:300px;"><strong>Licence Key </strong></label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea required type="text" name="licence_key" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->lic_key. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <strong>Billing Address</strong>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo ' <strong>Delivery Address / Shipping Address</strong>';
	echo ' </td>';
	echo '</tr>';
	
	// Billing Table
	echo '<tr >';
	echo ' <td colspan="1">';
	echo '<table width="410px" align="center" style=" border: 1px solid black; margin-top:5px; padding-top:5px; padding-left:5px; border-collapse:separate; border-spacing:1em;">';  
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_company">Company Name </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_company" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_company. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_addressline1">Address Line 1 </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_addressline1" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_addressline1. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_addressline2">Address Line 2 </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_addressline2" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_addressline2. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_city">City </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_city" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_city. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_county">County </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_county" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_county. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="billing_eircode">Eircode </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="billing_eircode" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->billing_eircode. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '</table>';
	echo ' </td>';
	
	
	// Delivery/Shipping Table
	
	echo ' <td colspan="1">';
	echo '<table id="tableDeliveryable" width="410px" align="center" style=" border: 1px solid black; margin-top:5px; padding-top:5px; padding-left:5px; border-collapse:separate; border-spacing:1em; ">';  
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_company">Company Name </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_company" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_company. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_addressline1">Address Line 1 </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_addressline1" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_addressline1. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_addressline2">Address Line 2 </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_addressline2" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_addressline2. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_city">City </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_city" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_city. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_county">County </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_county" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_county. '</textarea>';
	echo ' </td>';
	echo '</tr>';
	
	echo '<tr>';
	echo ' <td valign="top">';
	echo '  <label for="delivery_eircode">Eircode </label>';
	echo ' </td>';
	echo ' <td valign="top" >';
	echo '  <textarea type="text" name="delivery_eircode" maxlength="50" size="30" rows="1" cols="40" style=" resize: none; ">' . $DBP_results->delivery_eircode. '</textarea>';
	echo ' </td>';
	echo '</tr>';

	
	echo '</table>';
	echo ' </td>';
	echo '</tr >';
	
	echo '<tr>';
	echo ' <td colspan="2" style="text-align:center"  align="center">';
	echo ' <input type="submit" value="Submit" name="submit" style="height:30px; width:120px" class="button-primary"></input>';
	echo ' </td>';
	echo '</tr>';
	echo '</table>';
	
?>
<?php
	global $wpdb;
	$table_name= $wpdb->prefix."autoaddress";	
	$DBP_results = $wpdb->GET_ROW("SELECT * FROM $table_name ORDER BY created_date DESC LIMIT 1");
?>	
</form>

